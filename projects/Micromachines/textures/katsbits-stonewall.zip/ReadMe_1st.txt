-------------------------------------------------------------------------

TITLE : assorted stonewall textures
AUTHOR : ken 'kat' beyer
EMAIL ADDRESS : info@quake3bits.com
HOMEPAGE URL : http://www.quake3bits.com
NUMBER OF TEXTURES : 8
SHADER SCRIPTS : n/a

------------------
additional info
Misc stonewall textures of 'the olde worlde' type (not the usual 'big block' stonework of Quake 3). Has a sense of 'realism' so can be used for any game that supports the TGA image format.

Files provided on this page are packed into a zip file 'unpathed'. They will need extracting to the appropriate assets directory, i.e.

- textures/[your map or project folder]/
- textures/kt_stonewall/
- models/mapobjects/[your project folder]/

Let me know if you modify the textures as I like to see what peeps are doing with these things..!

------------------
* TEXTURE NAMES *
all files are *.tga format

**kt_stonewall**
256 x 1024
wall_1024_ivy_05
wall_1024_tex1_05

512 x 512
wall_1024_05
wall_512_1_05
wall_512_2_05
wall_512_3_05
wall_512_4_05
wall_512_5_05


------------------

CREDITS
ID software
=========================================================================
DISTRIBUTION
as long as this readme is included...!
***COMMERCIAL DISTRIBUTION PROHIBITED IN ANY FORM***

FOR COMMERCIAL USE PLEASE CONTACT THE AUTHOR ABOVE

--------------------------------------------------------------------------